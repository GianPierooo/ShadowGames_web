Shadow Games — Press kit
========================

Este press kit es una versión preliminar (fase 1).

Los logos incluidos son los placeholders actuales del estudio.
Cuando los assets definitivos del logo lleguen (mark / wordmark /
full, en SVG y PNG), regenera este ZIP con:

    npm run press:zip

Las carpetas de key-arts/ y screenshots/ están vacías o
incompletas en esta fase: se irán llenando a medida que cada
juego cierre su material visual.

Contacto de prensa: shadowgames.devteam@gmail.com
Web: https://shadowgames.studio

[!] No hay screenshots disponibles aún. Esta carpeta se actualizará a medida que cada juego cierre su material visual definitivo.